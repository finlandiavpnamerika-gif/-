#!/bin/sh
python3 -m pip install -r requirements.txt
python3 -m PyInstaller --noconfirm --onefile --windowed --name VisualsLauncher \
  --collect-all customtkinter --add-data "bundled:bundled" launcher.py
echo "Готово: dist/VisualsLauncher"
