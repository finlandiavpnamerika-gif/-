@echo off
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --onefile --windowed --name VisualsLauncher ^
  --collect-all customtkinter ^
  --add-data "bundled;bundled" launcher.py
echo.
echo Готово: dist\VisualsLauncher.exe
pause
