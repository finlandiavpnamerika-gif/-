# Visuals Launcher

Лаунчер для мода **ArchitektVisuals** (Fabric, Minecraft 1.21.11).

## Запуск из исходников
```
pip install -r requirements.txt
python launcher.py
```

## Сборка в один .exe
Запусти `build.bat` (Windows) или `build.sh` (Linux/macOS) → `dist/VisualsLauncher.exe`.
Мод из `bundled/` вшивается внутрь exe.

## Обновить мод
Положи новый `visualsmod-X.Y.Z.jar` в `bundled/` (старый удали) и пересобери.

## Где что лежит
Данные игры: `%APPDATA%\.visualslauncher` (mods, saves, настройки `launcher.json`).
Java ставится автоматически (рантайм Mojang), системная не нужна.
Вход — оффлайн по нику.

## EXE без Windows-компьютера
Залей папку в репозиторий на GitHub → вкладка Actions → «Build Windows EXE» → Run workflow.
Готовый VisualsLauncher.exe появится в Artifacts.
