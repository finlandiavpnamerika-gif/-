"""Visuals Launcher — лаунчер для мода ArchitektVisuals (Fabric, Minecraft 1.21.11)."""
import hashlib
import json
import os
import queue
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import tkinter as tk
import uuid
import urllib.parse
import urllib.request
from pathlib import Path
from tkinter import filedialog

import customtkinter as ctk
import minecraft_launcher_lib as mll
from PIL import Image, ImageOps, ImageTk

MC_VERSION = "1.21.11"
APP_NAME = "Visuals Launcher"
APP_VERSION = "1.1.0"

# ---------- тема ----------
BG = "#0d0e13"
SIDE = "#12131a"
CARD = "#171923"
CARD2 = "#1c1e2a"
BORDER = "#262836"
TEXT = "#e9eaf0"
MUTED = "#8a8ea3"
ACCENT = "#e0b44c"
ACCENT_HOVER = "#c99d36"
ACCENT_DARK = "#2a2414"
GREEN = "#4ade80"
RED = "#f87171"
FONT = "Segoe UI"


# ---------- пути и конфиг ----------
def resource_path(rel: str) -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).parent)) / rel


def data_dir() -> Path:
    if sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home())) / ".visualslauncher"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "visualslauncher"
    return Path.home() / ".visualslauncher"


GAME_DIR = data_dir()
MODS_DIR = GAME_DIR / "mods"
CFG_FILE = GAME_DIR / "launcher.json"

DEFAULT_CFG = {
    "accounts": ["Player"],
    "current": "Player",
    "ram_gb": 4,
    "jvm_args": "",
    "close_on_launch": False,
    "servers": [{"name": "Локальный сервер", "host": "localhost"}],
}


def load_cfg() -> dict:
    try:
        cfg = {**DEFAULT_CFG, **json.loads(CFG_FILE.read_text("utf-8"))}
    except Exception:
        cfg = json.loads(json.dumps(DEFAULT_CFG))
    if cfg["current"] not in cfg["accounts"]:
        cfg["accounts"].append(cfg["current"])
    return cfg


def save_cfg(cfg: dict) -> None:
    GAME_DIR.mkdir(parents=True, exist_ok=True)
    CFG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), "utf-8")


def valid_nick(n: str) -> bool:
    return 3 <= len(n) <= 16 and n.isascii() and all(c.isalnum() or c == "_" for c in n)


def open_path(p: Path):
    p.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        os.startfile(p)  # noqa
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(p)])
    else:
        subprocess.Popen(["xdg-open", str(p)])


# ---------- сеть ----------
def http_json(url: str):
    req = urllib.request.Request(url, headers={"User-Agent": "VisualsLauncher/1.1"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def download(url: str, dest: Path, sha1: str | None = None) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "VisualsLauncher/1.1"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)
    if sha1 and file_sha1(dest) != sha1:
        dest.unlink(missing_ok=True)
        raise RuntimeError(f"Контрольная сумма не совпала: {dest.name}")


def file_sha1(p: Path) -> str:
    h = hashlib.sha1()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def offline_uuid(nick: str) -> str:
    h = bytearray(hashlib.md5(f"OfflinePlayer:{nick}".encode()).digest())
    h[6] = (h[6] & 0x0F) | 0x30
    h[8] = (h[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(h)))


def _varint(n: int) -> bytes:
    out = b""
    while True:
        b = n & 0x7F
        n >>= 7
        out += bytes([b | (0x80 if n else 0)])
        if not n:
            return out


def ping_server(addr: str, timeout: float = 3.0):
    """Server List Ping. Возвращает (online, max, ms) или бросает исключение."""
    host, _, port = addr.partition(":")
    port = int(port) if port else 25565
    t0 = time.time()
    with socket.create_connection((host, port), timeout) as s:
        s.settimeout(timeout)
        hb = host.encode()
        data = b"\x00" + _varint(767) + _varint(len(hb)) + hb + struct.pack(">H", port) + _varint(1)
        s.sendall(_varint(len(data)) + data + b"\x01\x00")

        def rv():
            n = 0
            for i in range(5):
                b = s.recv(1)
                if not b:
                    raise IOError("closed")
                n |= (b[0] & 0x7F) << (7 * i)
                if not b[0] & 0x80:
                    return n
            raise IOError("varint")

        rv(); rv()
        ln = rv()
        buf = b""
        while len(buf) < ln:
            chunk = s.recv(ln - len(buf))
            if not chunk:
                break
            buf += chunk
    ms = int((time.time() - t0) * 1000)
    js = json.loads(buf.decode("utf-8", "replace"))
    return js["players"]["online"], js["players"]["max"], ms


# ---------- установка / запуск ----------
class Installer:
    def __init__(self, log, status, progress):
        self.log, self.status, self.progress = log, status, progress

    def cb(self):
        st = {"max": 1}
        return {
            "setStatus": lambda s: self.status(s),
            "setMax": lambda v: st.update(max=max(int(v), 1)),
            "setProgress": lambda v: self.progress(min(int(v) / st["max"], 1.0)),
        }

    def ensure_game(self) -> str:
        loader = mll.fabric.get_latest_loader_version()
        vid = f"fabric-loader-{loader}-{MC_VERSION}"
        if (GAME_DIR / "versions" / vid / f"{vid}.json").exists():
            self.log(f"Fabric уже установлен: {vid}")
            return vid
        self.status("Устанавливаю Minecraft и Fabric…")
        self.log(f"Устанавливаю Minecraft {MC_VERSION} + Fabric {loader}…")
        mll.fabric.install_fabric(MC_VERSION, str(GAME_DIR), loader_version=loader, callback=self.cb())
        return vid

    def ensure_java(self):
        component = "java-runtime-delta"
        try:
            vj = GAME_DIR / "versions" / MC_VERSION / f"{MC_VERSION}.json"
            component = json.loads(vj.read_text("utf-8"))["javaVersion"]["component"]
        except Exception:
            pass
        try:
            exe = mll.runtime.get_executable_path(component, str(GAME_DIR))
            if not exe:
                self.status("Скачиваю Java…")
                self.log(f"Скачиваю Java ({component})…")
                mll.runtime.install_jvm_runtime(component, str(GAME_DIR), callback=self.cb())
                exe = mll.runtime.get_executable_path(component, str(GAME_DIR))
            return exe
        except Exception as e:
            self.log(f"Java от Mojang не поставилась ({e}); пробую системную.")
            return shutil.which("java")

    def ensure_fabric_api(self):
        MODS_DIR.mkdir(parents=True, exist_ok=True)
        self.status("Проверяю Fabric API…")
        q = urllib.parse.urlencode({"game_versions": json.dumps([MC_VERSION]), "loaders": json.dumps(["fabric"])})
        versions = http_json(f"https://api.modrinth.com/v2/project/fabric-api/version?{q}")
        if not versions:
            raise RuntimeError(f"Fabric API для {MC_VERSION} не найден на Modrinth")
        files = versions[0]["files"]
        f = next((x for x in files if x.get("primary")), files[0])
        dest = MODS_DIR / f["filename"]
        if dest.exists() and file_sha1(dest) == f["hashes"]["sha1"]:
            self.log("Fabric API актуален.")
            return
        for old in MODS_DIR.glob("fabric-api-*.jar"):
            old.unlink(missing_ok=True)
        self.log(f"Скачиваю {f['filename']}…")
        download(f["url"], dest, f["hashes"]["sha1"])

    def ensure_mod(self):
        self.status("Устанавливаю мод…")
        jars = [p for p in sorted(resource_path("bundled").glob("visualsmod-*.jar")) if "sources" not in p.name]
        if not jars:
            raise RuntimeError("В папке bundled/ нет visualsmod-*.jar")
        src = jars[-1]
        dest = MODS_DIR / src.name
        if (MODS_DIR / (src.name + ".disabled")).exists():
            self.log("Мод выключен во вкладке «Моды» — пропускаю.")
            return
        if dest.exists() and file_sha1(dest) == file_sha1(src):
            self.log(f"Мод актуален: {src.name}")
            return
        for old in list(MODS_DIR.glob("visualsmod-*.jar")) + list(MODS_DIR.glob("visualsmod-*.jar.disabled")):
            old.unlink(missing_ok=True)
        shutil.copy2(src, dest)
        self.log(f"Мод установлен: {src.name}")

    def command(self, nick: str, ram: int, extra: str) -> list[str]:
        vid = self.ensure_game()
        java = self.ensure_java()
        self.ensure_fabric_api()
        self.ensure_mod()
        jvm = [f"-Xmx{ram}G", f"-Xms{min(ram, 2)}G"] + extra.split()
        opts = {
            "username": nick, "uuid": offline_uuid(nick), "token": "0",
            "launcherName": APP_NAME, "launcherVersion": APP_VERSION,
            "gameDirectory": str(GAME_DIR), "jvmArguments": jvm,
        }
        if java:
            opts["executablePath"] = java
        return mll.command.get_minecraft_command(vid, str(GAME_DIR), opts)


# ---------- виджеты ----------
def card(master, **kw):
    return ctk.CTkFrame(master, fg_color=CARD, corner_radius=14, border_width=1, border_color=BORDER, **kw)


def label(master, text, size=12, bold=False, color=TEXT, **kw):
    return ctk.CTkLabel(master, text=text, text_color=color,
                        font=ctk.CTkFont(family=FONT, size=size, weight="bold" if bold else "normal"), **kw)


def gold_btn(master, text, cmd, **kw):
    return ctk.CTkButton(master, text=text, command=cmd, fg_color=ACCENT, hover_color=ACCENT_HOVER,
                         text_color="#1a1405", font=ctk.CTkFont(family=FONT, size=14, weight="bold"),
                         corner_radius=10, **kw)


def ghost_btn(master, text, cmd, **kw):
    return ctk.CTkButton(master, text=text, command=cmd, fg_color="transparent", hover_color=CARD2,
                         border_width=1, border_color=BORDER, text_color=TEXT,
                         font=ctk.CTkFont(family=FONT, size=12), corner_radius=10, **kw)


class Hero(tk.Canvas):
    """Баннер с фоном и текстом поверх (Canvas, чтобы текст был прозрачным)."""

    def __init__(self, master):
        super().__init__(master, highlightthickness=0, bd=0, bg=CARD, height=250)
        self.base = None
        for name in ("bundled/ui/hero.jpg", "bundled/ui/hero.png"):
            try:
                self.base = Image.open(resource_path(name)).convert("RGB")
                break
            except Exception:
                pass
        self._tk = None
        self._size = (0, 0)
        self.bind("<Configure>", self.redraw)

    def _render(self, w, h):
        if self.base:
            bw, bh = self.base.size
            s = max(w / bw, h / bh)
            nw, nh = int(bw * s) + 1, int(bh * s) + 1
            im = self.base.resize((nw, nh), Image.LANCZOS)
            l, t = (nw - w) // 2, (nh - h) // 2
            im = im.crop((l, t, l + w, t + h))
        else:
            im = Image.new("RGB", (w, h), "#1b1d27")
        grad = ImageOps.invert(Image.linear_gradient("L").rotate(90)).resize((w, h))
        mask = grad.point(lambda v: int(35 + v * 0.65))
        return Image.composite(Image.new("RGB", (w, h), "#0c0d12"), im, mask)

    def redraw(self, _=None):
        w, h = self.winfo_width(), self.winfo_height()
        if w < 50 or h < 50 or (w, h) == self._size:
            return
        self._size = (w, h)
        self.delete("all")
        self._tk = ImageTk.PhotoImage(self._render(w, h))
        self.create_image(0, 0, image=self._tk, anchor="nw")
        p = 28
        self.create_rectangle(p, p, p + 168, p + 26, fill="#12131a", outline="#3a3d4d")
        self.create_text(p + 84, p + 13, text=f"MINECRAFT {MC_VERSION}", fill=TEXT, font=(FONT, 9, "bold"))
        y = h * 0.40
        self.create_text(p, y, text="Просто играй.", anchor="w", fill="#ffffff", font=(FONT, 30, "bold"))
        self.create_text(p, y + 46, text="В своём стиле.", anchor="w", fill=ACCENT, font=(FONT, 30, "bold"))
        self.create_text(p, y + 90, text="Один клик — и игра, Fabric и мод готовы.", anchor="w",
                         fill="#b9bccb", font=(FONT, 11))
        self.create_text(p, h - p + 6, text="●  FABRIC · JAVA 21", anchor="sw", fill="#9ea2b4", font=(FONT, 9, "bold"))


# ---------- приложение ----------
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.cfg = load_cfg()
        self.busy = False
        self.q: queue.Queue = queue.Queue()
        self.log_lines: list[str] = []

        self.title(APP_NAME)
        self.geometry("1100x700")
        self.minsize(980, 640)
        self.configure(fg_color=BG)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=0, column=1, sticky="nsew", padx=24, pady=20)
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(1, weight=1)

        self.title_lbl = label(self.content, "Главная", 24, True)
        self.title_lbl.grid(row=0, column=0, sticky="w", pady=(0, 14))

        self.pages = {}
        for name, builder in (("Главная", self._page_home), ("Моды", self._page_mods),
                              ("Аккаунты", self._page_accounts), ("Лог", self._page_log),
                              ("Настройки", self._page_settings)):
            f = ctk.CTkFrame(self.content, fg_color="transparent")
            f.grid(row=1, column=0, sticky="nsew")
            builder(f)
            self.pages[name] = f
        self.show("Главная")
        self.after(50, self._pump)
        self.after(400, self.refresh_servers)
        self.log(f"{APP_NAME} {APP_VERSION}. Данные: {GAME_DIR}")

    # ----- thread-safe UI -----
    def ui(self, fn):
        self.q.put(fn)

    def _pump(self):
        try:
            while True:
                self.q.get_nowait()()
        except queue.Empty:
            pass
        self.after(50, self._pump)

    def log(self, text: str):
        text = text.rstrip("\n")

        def _do():
            self.log_lines.append(text)
            self.logbox.configure(state="normal")
            self.logbox.insert("end", text + "\n")
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        self.ui(_do)

    def set_status(self, t):
        self.ui(lambda: self.status_lbl.configure(text=t))

    def set_progress(self, v):
        self.ui(lambda: self.bar.set(v))

    # ----- sidebar -----
    def _build_sidebar(self):
        side = ctk.CTkFrame(self, width=240, corner_radius=0, fg_color=SIDE)
        side.grid(row=0, column=0, sticky="nsew")
        side.grid_propagate(False)

        logo = ctk.CTkFrame(side, fg_color="transparent")
        logo.pack(fill="x", padx=22, pady=(24, 4))
        label(logo, "◆", 22, True, ACCENT).pack(side="left")
        label(logo, " VISUALS", 19, True).pack(side="left")
        label(side, "Играй в своём стиле", 11, color=MUTED, anchor="w").pack(fill="x", padx=24, pady=(0, 22))
        label(side, "ТВОЁ ПРОСТРАНСТВО", 9, True, MUTED, anchor="w").pack(fill="x", padx=24, pady=(0, 6))

        self.nav = {}
        for name, icon in (("Главная", "⌂"), ("Моды", "▣"), ("Аккаунты", "☺"), ("Лог", "≡"), ("Настройки", "⚙")):
            b = ctk.CTkButton(side, text=f"  {icon}   {name}", anchor="w", height=42, corner_radius=10,
                              fg_color="transparent", hover_color=CARD2, text_color=MUTED,
                              border_width=1, border_color=SIDE,
                              font=ctk.CTkFont(family=FONT, size=13), command=lambda n=name: self.show(n))
            b.pack(fill="x", padx=14, pady=2)
            self.nav[name] = b

        prof = ctk.CTkFrame(side, fg_color=CARD, corner_radius=12, border_width=1, border_color=BORDER)
        prof.pack(side="bottom", fill="x", padx=14, pady=16)
        av = ctk.CTkFrame(prof, width=36, height=36, corner_radius=18, fg_color=ACCENT_DARK)
        av.pack(side="left", padx=10, pady=10)
        av.pack_propagate(False)
        self.av_lbl = label(av, self.cfg["current"][:1].upper(), 14, True, ACCENT)
        self.av_lbl.pack(expand=True)
        col = ctk.CTkFrame(prof, fg_color="transparent")
        col.pack(side="left", fill="x")
        self.side_nick = label(col, self.cfg["current"], 13, True, anchor="w")
        self.side_nick.pack(anchor="w")
        label(col, "Оффлайн-аккаунт", 10, color=MUTED, anchor="w").pack(anchor="w")

    def show(self, name):
        for n, b in self.nav.items():
            on = n == name
            b.configure(fg_color=ACCENT_DARK if on else "transparent",
                        border_color=ACCENT if on else SIDE,
                        text_color=ACCENT if on else MUTED)
        self.title_lbl.configure(text=name)
        self.pages[name].tkraise()
        if name == "Моды":
            self.refresh_mods()
        if name == "Аккаунты":
            self.refresh_accounts()

    # ----- главная -----
    def _page_home(self, f):
        f.grid_columnconfigure(0, weight=3)
        f.grid_columnconfigure(1, weight=2, minsize=300)
        f.grid_rowconfigure(0, weight=1)

        left = ctk.CTkFrame(f, fg_color="transparent")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        left.grid_columnconfigure(0, weight=1)
        left.grid_rowconfigure(0, weight=1)

        hero_wrap = ctk.CTkFrame(left, fg_color=CARD, corner_radius=16, border_width=1, border_color=BORDER)
        hero_wrap.grid(row=0, column=0, sticky="nsew", pady=(0, 14))
        Hero(hero_wrap).pack(fill="both", expand=True, padx=2, pady=2)

        play = card(left)
        play.grid(row=1, column=0, sticky="ew", pady=(0, 14))
        play.grid_columnconfigure(0, weight=1)
        self.status_lbl = label(play, "Готов к запуску", 14, True, anchor="w")
        self.status_lbl.grid(row=0, column=0, columnspan=3, sticky="w", padx=18, pady=(14, 0))
        label(play, f"Minecraft {MC_VERSION} · Fabric", 11, color=MUTED, anchor="w").grid(
            row=1, column=0, columnspan=3, sticky="w", padx=18)
        self.bar = ctk.CTkProgressBar(play, progress_color=ACCENT, fg_color=CARD2, height=5)
        self.bar.set(0)
        self.bar.grid(row=2, column=0, columnspan=3, sticky="ew", padx=18, pady=10)

        self.acc_menu = ctk.CTkOptionMenu(play, values=self.cfg["accounts"], width=170, fg_color=CARD2,
                                          button_color=CARD2, button_hover_color=BORDER,
                                          command=self.set_current)
        self.acc_menu.set(self.cfg["current"])
        self.acc_menu.grid(row=3, column=0, sticky="w", padx=18, pady=(0, 16))
        self.ram_lbl = label(play, f"{self.cfg['ram_gb']} ГБ", 12, color=MUTED)
        self.ram_lbl.grid(row=3, column=1, padx=10, pady=(0, 16))
        self.play_btn = gold_btn(play, "Играть  ▶", self.on_play, width=170, height=42)
        self.play_btn.grid(row=3, column=2, padx=18, pady=(0, 16))

        right = ctk.CTkFrame(f, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew")
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(0, weight=1)

        srv = card(right)
        srv.grid(row=0, column=0, sticky="nsew", pady=(0, 14))
        srv.grid_columnconfigure(0, weight=1)
        srv.grid_rowconfigure(1, weight=1)
        head = ctk.CTkFrame(srv, fg_color="transparent")
        head.grid(row=0, column=0, sticky="ew", padx=14, pady=(12, 4))
        label(head, "Твои серверы", 14, True).pack(side="left")
        ctk.CTkButton(head, text="+", width=30, height=30, fg_color=ACCENT_DARK, hover_color=BORDER,
                      text_color=ACCENT, command=self.add_server).pack(side="right")
        ctk.CTkButton(head, text="⟳", width=30, height=30, fg_color="transparent", hover_color=CARD2,
                      text_color=MUTED, command=self.refresh_servers).pack(side="right", padx=4)
        self.srv_list = ctk.CTkScrollableFrame(srv, fg_color="transparent")
        self.srv_list.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 8))

        news = card(right)
        news.grid(row=1, column=0, sticky="ew")
        label(news, "Что нового", 14, True, anchor="w").pack(fill="x", padx=14, pady=(12, 2))
        label(news, f"Лаунчер {APP_VERSION}: вкладки «Моды» и «Аккаунты», пинг серверов,\n"
                    "автоустановка Fabric API и Java.", 11, color=MUTED, anchor="w", justify="left").pack(
            fill="x", padx=14, pady=(0, 12))

    def set_current(self, nick):
        self.cfg["current"] = nick
        save_cfg(self.cfg)
        self.side_nick.configure(text=nick)
        self.av_lbl.configure(text=nick[:1].upper())

    # ----- серверы -----
    def refresh_servers(self):
        for w in self.srv_list.winfo_children():
            w.destroy()
        rows = {}
        for i, s in enumerate(self.cfg["servers"]):
            row = ctk.CTkFrame(self.srv_list, fg_color=CARD2, corner_radius=10)
            row.pack(fill="x", pady=3, padx=2)
            dot = label(row, "●", 12, color=MUTED)
            dot.pack(side="right", padx=(0, 10))
            rm = ctk.CTkButton(row, text="✕", width=24, height=24, fg_color="transparent", hover_color=BORDER,
                               text_color=MUTED, command=lambda i=i: self.del_server(i))
            rm.pack(side="right")
            col = ctk.CTkFrame(row, fg_color="transparent")
            col.pack(side="left", padx=10, pady=8)
            label(col, s["name"], 13, True, anchor="w").pack(anchor="w")
            info = label(col, f"{s['host']} · …", 10, color=MUTED, anchor="w")
            info.pack(anchor="w")
            rows[i] = (info, dot)
        if not self.cfg["servers"]:
            label(self.srv_list, "Нет серверов. Нажми «+»", 11, color=MUTED).pack(pady=20)

        def work(i, s):
            try:
                on, mx, ms = ping_server(s["host"])
                self.ui(lambda: (rows[i][0].configure(text=f"{on:,} / {mx:,} · {ms} ms".replace(",", " ")),
                                 rows[i][1].configure(text_color=GREEN)))
            except Exception:
                self.ui(lambda: (rows[i][0].configure(text=f"{s['host']} · недоступен"),
                                 rows[i][1].configure(text_color=RED)))
        for i, s in enumerate(self.cfg["servers"]):
            threading.Thread(target=work, args=(i, s), daemon=True).start()

    def add_server(self):
        name = ctk.CTkInputDialog(text="Название сервера:", title="Новый сервер").get_input()
        if not name:
            return
        host = ctk.CTkInputDialog(text="Адрес (host или host:port):", title="Новый сервер").get_input()
        if not host:
            return
        self.cfg["servers"].append({"name": name.strip(), "host": host.strip()})
        save_cfg(self.cfg)
        self.refresh_servers()

    def del_server(self, i):
        self.cfg["servers"].pop(i)
        save_cfg(self.cfg)
        self.refresh_servers()

    # ----- моды -----
    def _page_mods(self, f):
        f.grid_columnconfigure(0, weight=1)
        f.grid_rowconfigure(1, weight=1)
        bar = ctk.CTkFrame(f, fg_color="transparent")
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        gold_btn(bar, "+ Добавить мод", self.add_mod, height=36, width=150).pack(side="left")
        ghost_btn(bar, "Открыть папку", lambda: open_path(MODS_DIR), height=36).pack(side="left", padx=8)
        self.mods_list = ctk.CTkScrollableFrame(f, fg_color=CARD, corner_radius=14, border_width=1,
                                                border_color=BORDER)
        self.mods_list.grid(row=1, column=0, sticky="nsew")

    def refresh_mods(self):
        for w in self.mods_list.winfo_children():
            w.destroy()
        MODS_DIR.mkdir(parents=True, exist_ok=True)
        files = sorted(list(MODS_DIR.glob("*.jar")) + list(MODS_DIR.glob("*.jar.disabled")))
        if not files:
            label(self.mods_list, "Папка модов пуста. Моды появятся после первого запуска.", 12, color=MUTED).pack(pady=30)
        for p in files:
            enabled = p.suffix == ".jar"
            core = p.name.startswith("fabric-api")
            row = ctk.CTkFrame(self.mods_list, fg_color=CARD2, corner_radius=10)
            row.pack(fill="x", pady=3, padx=4)
            label(row, p.name.replace(".disabled", ""), 13, True).pack(side="left", padx=14, pady=12)
            label(row, f"{p.stat().st_size / 1048576:.1f} МБ", 11, color=MUTED).pack(side="left")
            sw = ctk.CTkSwitch(row, text="", progress_color=ACCENT, width=44,
                               command=lambda p=p: self.toggle_mod(p))
            if enabled:
                sw.select()
            if core:
                sw.configure(state="disabled")
                label(row, "обязательный", 10, color=MUTED).pack(side="right", padx=(0, 6))
            sw.pack(side="right", padx=14)

    def toggle_mod(self, p: Path):
        new = p.with_suffix("") if p.suffix == ".disabled" else p.with_name(p.name + ".disabled")
        try:
            p.rename(new)
        except OSError as e:
            self.log(f"Не удалось переименовать {p.name}: {e}")
        self.refresh_mods()

    def add_mod(self):
        files = filedialog.askopenfilenames(title="Выбери моды", filetypes=[("Fabric мод", "*.jar")])
        MODS_DIR.mkdir(parents=True, exist_ok=True)
        for fp in files:
            shutil.copy2(fp, MODS_DIR / Path(fp).name)
            self.log(f"Добавлен мод: {Path(fp).name}")
        self.refresh_mods()

    # ----- аккаунты -----
    def _page_accounts(self, f):
        f.grid_columnconfigure(0, weight=1)
        f.grid_rowconfigure(1, weight=1)
        bar = ctk.CTkFrame(f, fg_color="transparent")
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        self.new_nick = ctk.CTkEntry(bar, placeholder_text="Новый ник", width=220, height=36,
                                     fg_color=CARD, border_color=BORDER)
        self.new_nick.pack(side="left")
        gold_btn(bar, "Добавить", self.add_account, height=36, width=110).pack(side="left", padx=8)
        self.acc_err = label(bar, "", 11, color=RED)
        self.acc_err.pack(side="left", padx=8)
        self.acc_list = ctk.CTkScrollableFrame(f, fg_color=CARD, corner_radius=14, border_width=1,
                                               border_color=BORDER)
        self.acc_list.grid(row=1, column=0, sticky="nsew")

    def refresh_accounts(self):
        for w in self.acc_list.winfo_children():
            w.destroy()
        for n in self.cfg["accounts"]:
            cur = n == self.cfg["current"]
            row = ctk.CTkFrame(self.acc_list, fg_color=ACCENT_DARK if cur else CARD2, corner_radius=10,
                               border_width=1 if cur else 0, border_color=ACCENT)
            row.pack(fill="x", pady=3, padx=4)
            label(row, n, 14, True, ACCENT if cur else TEXT).pack(side="left", padx=14, pady=12)
            label(row, offline_uuid(n), 10, color=MUTED).pack(side="left")
            if len(self.cfg["accounts"]) > 1:
                ctk.CTkButton(row, text="Удалить", width=70, height=28, fg_color="transparent",
                              hover_color=BORDER, text_color=RED,
                              command=lambda n=n: self.del_account(n)).pack(side="right", padx=8)
            if not cur:
                ctk.CTkButton(row, text="Выбрать", width=70, height=28, fg_color=CARD, hover_color=BORDER,
                              text_color=TEXT, command=lambda n=n: self.pick_account(n)).pack(side="right")

    def _sync_accounts(self):
        self.acc_menu.configure(values=self.cfg["accounts"])
        self.acc_menu.set(self.cfg["current"])
        self.side_nick.configure(text=self.cfg["current"])
        self.av_lbl.configure(text=self.cfg["current"][:1].upper())
        save_cfg(self.cfg)
        self.refresh_accounts()

    def add_account(self):
        n = self.new_nick.get().strip()
        if not valid_nick(n):
            self.acc_err.configure(text="3–16 символов: латиница, цифры, _")
            return
        self.acc_err.configure(text="")
        if n not in self.cfg["accounts"]:
            self.cfg["accounts"].append(n)
        self.cfg["current"] = n
        self.new_nick.delete(0, "end")
        self._sync_accounts()

    def pick_account(self, n):
        self.cfg["current"] = n
        self._sync_accounts()

    def del_account(self, n):
        self.cfg["accounts"].remove(n)
        if self.cfg["current"] == n:
            self.cfg["current"] = self.cfg["accounts"][0]
        self._sync_accounts()

    # ----- лог -----
    def _page_log(self, f):
        f.grid_columnconfigure(0, weight=1)
        f.grid_rowconfigure(0, weight=1)
        self.logbox = ctk.CTkTextbox(f, fg_color=CARD, text_color="#c9cde0", border_width=1, border_color=BORDER,
                                     corner_radius=14, font=ctk.CTkFont(family="Consolas", size=12), wrap="word")
        self.logbox.grid(row=0, column=0, sticky="nsew")
        self.logbox.configure(state="disabled")

    # ----- настройки -----
    def _page_settings(self, f):
        f.grid_columnconfigure(0, weight=1)
        c = card(f)
        c.grid(row=0, column=0, sticky="ew")
        label(c, "Оперативная память", 13, True, anchor="w").pack(fill="x", padx=18, pady=(16, 0))
        self.set_ram_lbl = label(c, f"{self.cfg['ram_gb']} ГБ", 11, color=MUTED, anchor="w")
        self.set_ram_lbl.pack(fill="x", padx=18)
        self.ram = ctk.CTkSlider(c, from_=2, to=16, number_of_steps=14, button_color=ACCENT,
                                 button_hover_color=ACCENT_HOVER, progress_color=ACCENT, command=self._on_ram)
        self.ram.set(self.cfg["ram_gb"])
        self.ram.pack(fill="x", padx=18, pady=(4, 14))

        label(c, "Дополнительные аргументы JVM", 13, True, anchor="w").pack(fill="x", padx=18)
        self.jvm = ctk.CTkEntry(c, fg_color=CARD2, border_color=BORDER, height=36)
        self.jvm.insert(0, self.cfg["jvm_args"])
        self.jvm.pack(fill="x", padx=18, pady=(4, 14))

        self.close_var = ctk.BooleanVar(value=self.cfg["close_on_launch"])
        ctk.CTkSwitch(c, text="Закрывать лаунчер после запуска игры", variable=self.close_var,
                      progress_color=ACCENT).pack(anchor="w", padx=18, pady=(0, 14))

        row = ctk.CTkFrame(c, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=(0, 16))
        gold_btn(row, "Сохранить", self.save_settings, height=36, width=120).pack(side="left")
        ghost_btn(row, "Папка игры", lambda: open_path(GAME_DIR), height=36).pack(side="left", padx=8)
        ghost_btn(row, "Переустановить Fabric", self.reinstall, height=36).pack(side="left")

    def _on_ram(self, v):
        self.set_ram_lbl.configure(text=f"{int(v)} ГБ")

    def save_settings(self):
        self.cfg.update(ram_gb=int(self.ram.get()), jvm_args=self.jvm.get().strip(),
                        close_on_launch=self.close_var.get())
        save_cfg(self.cfg)
        self.ram_lbl.configure(text=f"{self.cfg['ram_gb']} ГБ")
        self.log("Настройки сохранены.")

    def reinstall(self):
        vdir = GAME_DIR / "versions"
        if vdir.exists():
            for d in vdir.glob("fabric-loader-*"):
                shutil.rmtree(d, ignore_errors=True)
        self.log("Fabric будет установлен заново при следующем запуске.")

    # ----- запуск -----
    def on_play(self):
        if self.busy:
            return
        nick = self.cfg["current"]
        if not valid_nick(nick):
            self.set_status("Некорректный ник — исправь во вкладке «Аккаунты»")
            return
        self.save_settings()
        self.busy = True
        self.play_btn.configure(state="disabled", text="Подготовка…")
        threading.Thread(target=self._run, args=(nick,), daemon=True).start()

    def _run(self, nick):
        try:
            GAME_DIR.mkdir(parents=True, exist_ok=True)
            inst = Installer(self.log, self.set_status, self.set_progress)
            cmd = inst.command(nick, self.cfg["ram_gb"], self.cfg["jvm_args"])
            self.set_progress(1.0)
            self.log("Запускаю Minecraft…")
            flags = 0x08000000 if sys.platform == "win32" else 0
            proc = subprocess.Popen(cmd, cwd=str(GAME_DIR), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, errors="replace", creationflags=flags)
            self.set_status("Minecraft запущен.")
            self.ui(lambda: self.play_btn.configure(text="В игре"))
            if self.cfg["close_on_launch"]:
                self.ui(lambda: self.after(3000, self.destroy))
                return
            for line in proc.stdout:
                self.log(line)
            self.log(f"Игра закрыта (код {proc.wait()}).")
            self.set_status("Готов к запуску")
        except Exception as e:
            self.log(f"✖ Ошибка: {e}")
            self.set_status("Ошибка — подробности во вкладке «Лог»")
        finally:
            self.busy = False
            self.set_progress(0)
            self.ui(lambda: self.play_btn.configure(state="normal", text="Играть  ▶"))


if __name__ == "__main__":
    App().mainloop()
